package roborace.server;

import COSC3P91.xml.XMLObject;
import java.awt.Point;
import roborace.common.Direction;

public class Board implements XMLObject {

    private final Factory factory;
    private final Robot[] robots;

    public Board(Factory factory, Robot[] robots) {
        this.factory = factory;
        this.robots = robots;
    }

    public Robot getRobotByID(int playerID) {
        return robots[playerID];
    }

    public void revitalize(EventList events) {
        for (int i = 0; i < robots.length; i++) {
            if (!robots[i].isAlive()) {
                int startIndex;
                if (robotIDAt(factory.getStartConfigByID(i).getFirst()) == -1) {
                    startIndex = i;
                } else {
                    startIndex = -1;
                    for (int j = 0; j < factory.getMaxPlayers(); j++) {
                        if (startIndex == -1 && robotIDAt(factory.getStartConfigByID(j).getFirst()) == -1) {
                            startIndex = j;
                        }
                    }
                }
                robots[i].revitalize(factory.getStartConfigByID(startIndex));
                events.add(new EventRevitalize(i, startIndex));
            }
        }
    }

    public void step(EventList events, int playerID, Direction direction) {
        //destroyedEvent list
        EventList destroyedEvents = new EventList();

        //call stepRecursive 3 parameters
        stepRecursive(events, destroyedEvents, playerID, direction);

        //add eventWait to events
        events.add(new EventWait());

        //if destroyedEvents is not empty
        if (!destroyedEvents.isEmpty()) {
            //add all to events
            events.addAll(destroyedEvents);
            //add additional EventWait
            events.add(new EventWait());
        }
    }
    if()

    {

    }
}

    //method to move the robot
    private void stepRecursive(EventList events, EventList destroyedEvents, int playerID, Direction direction) {
        Robot robot = robots[playerID];
        Point currentPosition = robot.getPosition();

        //if factory has a wall
        if (factory.hasWall(currentPosition, direction)) {
            //create new event EventBump and add to the event list
            events.add(new EventBump(playerID, direction));

        } else {// else compute position to where the robot should be moved

            Point newPosition = null;
            switch (direction) {
                //north position
                case North:
                    newPosition = new Point(currentPosition.x, currentPosition.y - 1);
                    break;
                //south position
                case South:
                    newPosition = new Point(currentPosition.x, currentPosition.y + 1);
                    break;
                //east position
                case East:
                    newPosition = new Point(currentPosition.x + 1, currentPosition.y);
                    break;
                //west position  
                case West:
                    newPosition = new Point(currentPosition.x - 1, currentPosition.y);
                    break;
            }
            if (newPosition.x < 0
                    || newPosition.x >= factory.getXSize()
                    || newPosition.y < 0
                    || newPosition.y >= factory.getYSize()
                    || factory.isPitAt(newPosition)) {
                //set new position
                robot.setPosition(newPosition);
                //kill robot
                robot.destroyed();
                //create an EventStep and add to list
                events.add(new EventStep(playerID, direction));
                destroyedEvents.add(new EventDestroyed(playerID));

            } else {
                //check if new position is occupied by a robot
                int robot2 = robotIDAt(newPosition);
                if (robot2 == -1) {
                    //set new position
                    robot.setPosition(newPosition);
                    //create an EventStep and add to event list
                    events.add(new EventStep(playerID, direction));
                } else {//othersise call stepRecursive for robot in new position
                    stepRecursive(events, destroyedEvents, robot2, direction);
                    //check if new position is free
                    if (robotIDAt(newPosition) != -1) {
                        //create EventBump and add to event list
                        events.add(new EventBump(playerID, direction));
                    } else {
                        //create EventStep and add to event list
                        events.add(new EventStep(playerID, direction));
                    }
                }
            }
        }
    }

    public void effect(EventList events, int playerID, int phase) {
        if (getRobotByID(playerID).isAlive() && !events.containsVictory()) {
            factory.effect(events, phase, playerID, this);
        }
    }

    @Override
    public String toXMLString() {
        String result = "<Board>\n";
        result += "<Robots number=\"" + robots.length + "\">\n";
        for (Robot robot : robots) {
            result += robot.toXMLString() + "\n";
        }
        result += "</Robots>\n";
        result += factory.toXMLString() + "\n";
        return result + "</Board>";
    }

    private int robotIDAt(Point p) {
        int result = -1;
        for (int i = 0; i < robots.length; i++) {
            if (p.equals(robots[i].getPosition())) {
                result = i;
            }
        }
        return result;
    }
}
