package roborace.server;

public class TileGoal implements Tile {

    @Override
    public void effect(EventList events, int playerID, Board board) {
        //add EventVictory to event list
        events.add(new EventVictory(playerID));

    }

    @Override
    public String toXMLString() {
        return "<TileGoal/>";
    }
}
