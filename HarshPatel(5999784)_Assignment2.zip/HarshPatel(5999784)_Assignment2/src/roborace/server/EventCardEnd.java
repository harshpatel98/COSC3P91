package roborace.server;

public class EventCardEnd implements Event {

    @Override
    public String toXMLString() {
        return "<EventCardEnd/>";
    }
}

