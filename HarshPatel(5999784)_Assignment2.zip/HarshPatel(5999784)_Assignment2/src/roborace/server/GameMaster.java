package roborace.server;

import roborace.client.Player;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.IOException;

public class GameMaster {

    private final Robot[] robots;
    private final Player[] players;
    private final Board board;
    private final CardFactory cardFactory;

    public GameMaster(String[] names, Player[] players) {
        this.players = players;
        robots = new Robot[names.length];
        Factory factory = Factory.load("factory.xml");
        for (int i=0; i<names.length; i++) {
            robots[i] = new Robot(names[i],factory.getStartConfigByID(i),true);
        }
        board = new Board(factory,robots);
        for (Player p : players) {
            p.receiveBoard(board);
        }
        cardFactory = new CardFactory();
    }

    public void run() {
        final int numberPlayers = robots.length;
        CardList[] pCardList  = new CardList[numberPlayers];
        for(int i=0; i<numberPlayers; i++) {
            pCardList[i] = new CardList();
        }
        CardList phaseList = new CardList();
        EventList events = new EventList();
        List<Integer> effectExecutionOrder = new ArrayList<Integer>(numberPlayers);
        for (int i=0; i<numberPlayers; i++) {
            effectExecutionOrder.add(i);
        }
        int phase;
        while (!events.containsVictory()) {
            for (int i=0; i<numberPlayers; i++) {
                pCardList[i].clear();
                for (int j=0; j<7; j++) {
                    pCardList[i].add(cardFactory.createCard(i));
                }
                pCardList[i] = players[i].selectCards(pCardList[i]);
            }
            phase = 0;
            events.clear();
            while (phase < 5 && !events.containsVictory()) {
                phase++;
                phaseList.clear();
                for (int i=0; i<numberPlayers; i++) {
                    phaseList.add(pCardList[i].get(phase-1));
                }
                Collections.sort(phaseList);
                for (Card card : phaseList) {
                    card.execute(events,board);
                }
                Collections.sort(effectExecutionOrder);
                Collections.shuffle(effectExecutionOrder);
                for(int playerID : effectExecutionOrder) {
                    board.effect(events,playerID,phase);
                }
                if (!events.containsVictory()) {
                    events.add(new EventRunDecorations(phase));
                }               
            }
            if (!events.containsVictory()) {
                board.revitalize(events);
            }
            for(Player p : players) {
                p.receiveEvents(events);
            }
        }
    }
}
		