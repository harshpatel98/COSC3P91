package roborace.server;

public class TilePit implements Tile {
	
    @Override
    public void effect(EventList events, int playerID, Board board) {
        // no effect, handled in method "step"
    }
	
    @Override
    public String toXMLString() {
	return "<TilePit/>";
    }	
}