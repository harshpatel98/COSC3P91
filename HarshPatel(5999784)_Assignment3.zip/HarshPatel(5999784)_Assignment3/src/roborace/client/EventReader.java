package roborace.client;

import COSC3P91.xml.XMLNodeConverter;
import java.util.List;
import org.w3c.dom.Node;
import roborace.common.Direction;

import static COSC3P91.xml.XMLTools.getBoolAttribute;
import static COSC3P91.xml.XMLTools.getChildNodes;
import static COSC3P91.xml.XMLTools.getEnumAttribute;
import static COSC3P91.xml.XMLTools.getIntAttribute;

public class EventReader implements XMLNodeConverter<Event> {

    //cardReader
    private final CardReader cardReader;

    public EventReader() {
        cardReader = new CardReader();
    }

    @Override
    public Event convertXMLNode(Node node) {

        //events from TestClass
        Event event = null;
        String name = node.getNodeName();

        //code from TestClass for guidance
        //EventBump
        /*result = new roborace.server.EventBump(playerID.getInt(event),(Direction) direction.get(event)).toXMLString();
         */
        if (name.equals("EventBump")) {
            event = new EventBump(getIntAttribute(node, "playerID"), (Direction) getEnumAttribute(Direction.class, node, "direction"));
        }

        //EventCardEnd (newCard end)
        //result = new roborace.server.EventCardEnd().toXMLString();
        if (name.equals("EventCardEnd")) {
            event = new EventCardEnd();
        }

        //EventCardStart
        //result = "<EventCardStart>" + ((roborace.client.Card) card.get(event)).toXMLString() + "</EventCardStart>";
        if (name.equals("EventCardStart")) {
            List<Node> list = getChildNodes(node);
            event = new EventCardStart(cardReader.convertXMLNode(list.get(0)));
        }

        //EventDestdoyed
        //result = new roborace.server.EventDestroyed(playerID.getInt(event)).toXMLString();
        if (name.equals("EventDestroyed")) {
            event = new EventDestroyed(getIntAttribute(node, "playerID"));
        }

        //EventEffectEnd(new event effect end
        //result = new roborace.server.EventEffectEnd().toXMLString();
        if (name.equals("EventEffectEnd")) {
            event = new EventEffectEnd();
        }

        //EventEffectStart
        //result = new roborace.server.EventEffectStart(new Point(x.getInt(event),y.getInt(event)),playerID.getInt(event),isDecorationEffect.getBoolean(event)).toXMLString();
        //field x, and y
        if (name.equals("EventEffectStart")) {
            event = new EventEffectStart(getIntAttribute(node, "x"), getIntAttribute(node, "y"), getIntAttribute(node, "playerID"), getBoolAttribute(node, "isDecorationEffect"));
        }

        //EventRevitalize
        //result = new roborace.server.EventRevitalize(playerID.getInt(event),startID.getInt(event)).toXMLString();
        if (name.equals("EventRevitalize")) {
            event = new EventRevitalize(getIntAttribute(node, "playerID"), getIntAttribute(node, "startID"));
        }

        //EventRunDecorations
        //result = new roborace.server.EventRunDecorations(phase.getInt(event)).toXMLString();
        if (name.equals("EventRunDecorations")) {
            event = new EventRunDecorations(getIntAttribute(node, "phase"));
        }

        //EventStep
        //result = new roborace.server.EventStep(playerID.getInt(event),(Direction) direction.get(event)).toXMLString();
        if (name.equals("EventStep")) {
            event = new EventStep(getIntAttribute(node, "playerID"), (Direction) getEnumAttribute(Direction.class, node, "direction"));
        }

        //EventTurn90
        //result = new roborace.server.EventTurn90(playerID.getInt(event),clockwise.getBoolean(event)).toXMLString();
        if (name.equals("EventTurn90")) {
            event = new EventTurn90(getIntAttribute(node, "playerID"), getBoolAttribute(node, "clockwise"));
        }

        //EventTurn180
        //result = new roborace.server.EventTurn180(playerID.getInt(event)).toXMLString();
        if (name.equals("EventTurn180")) {
            event = new EventTurn180(getIntAttribute(node, "playerID"));
        }

        //EventVictory
        //result = new roborace.server.EventVictory(playerID.getInt(event)).toXMLString();
        if (name.equals("EventVictory")) {
            event = new EventVictory(getIntAttribute(node, "playerID"));
        }

        //EventWait
        //result = new roborace.server.EventWait().toXMLString();
        if (name.equals("EventWait")) {
            event = new EventWait();
        }

        return event;
    }
}
