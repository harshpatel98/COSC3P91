package roborace.client;

public class EventCardEnd implements Event {

    @Override
    public void execute(AnimatedBoard board, InfoPane infoPane) {

        //wait for animation
        board.waitOnAnimations();
        try {
            //sleep for 1s
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
        //infor wait on single step and display info
        infoPane.waitOnSingleStep();
        infoPane.displayNoInfo();
    }
}
