package roborace.client;

public class EventEffectEnd implements Event {

    @Override
    public void execute(AnimatedBoard board, InfoPane infoPane) {
        
        //same as EventCardEnd
        //wait for animation
        board.waitOnAnimations();
        try {
            //sleep for 1s
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
        //infor wait on single step and display info
        infoPane.waitOnSingleStep();
        infoPane.displayNoInfo();
    } 
}
