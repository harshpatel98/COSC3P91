package roborace.client;

public interface Event {
	
    public void execute(AnimatedBoard board, InfoPane infoPane);	
}