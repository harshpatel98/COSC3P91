package roborace.client;

public class EventWait implements Event {

    @Override
    public void execute(AnimatedBoard board, InfoPane infoPane) {
        //call watit on animation
        board.waitOnAnimations();
    }
}
