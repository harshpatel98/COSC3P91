package roborace;

import COSC3P91.graphics.ImageManager;
import COSC3P91.xml.XMLReader;
import java.awt.Point;
import java.io.StringReader;
import java.lang.reflect.Field;
import roborace.client.EventReader;
import roborace.client.ImageAndAnimationFactory;
import roborace.common.Direction;
import static roborace.common.Direction.*;

public class TestClass {

    public static String ToXMLString(roborace.client.Event event) {
        String result = null;
        Class clazz;
        try {
            if (event instanceof roborace.client.EventBump) {
                clazz = roborace.client.EventBump.class;
                Field playerID = clazz.getDeclaredField("playerID");
                Field direction = clazz.getDeclaredField("direction");
                playerID.setAccessible(true);
                direction.setAccessible(true);
                result = new roborace.server.EventBump(playerID.getInt(event), (Direction) direction.get(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventCardEnd) {
                result = new roborace.server.EventCardEnd().toXMLString();
            }
            if (event instanceof roborace.client.EventCardStart) {
                clazz = roborace.client.EventCardStart.class;
                Field card = clazz.getDeclaredField("card");
                card.setAccessible(true);
                result = "<EventCardStart>" + ((roborace.client.Card) card.get(event)).toXMLString() + "</EventCardStart>";
            }
            if (event instanceof roborace.client.EventDestroyed) {
                clazz = roborace.client.EventDestroyed.class;
                Field playerID = clazz.getDeclaredField("playerID");
                playerID.setAccessible(true);
                result = new roborace.server.EventDestroyed(playerID.getInt(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventEffectEnd) {
                result = new roborace.server.EventEffectEnd().toXMLString();
            }
            if (event instanceof roborace.client.EventEffectStart) {
                clazz = roborace.client.EventEffectStart.class;
                Field playerID = clazz.getDeclaredField("playerID");
                Field x = clazz.getDeclaredField("x");
                Field y = clazz.getDeclaredField("y");
                Field isDecorationEffect = clazz.getDeclaredField("isDecorationEffect");
                playerID.setAccessible(true);
                x.setAccessible(true);
                y.setAccessible(true);
                isDecorationEffect.setAccessible(true);
                result = new roborace.server.EventEffectStart(new Point(x.getInt(event), y.getInt(event)), playerID.getInt(event), isDecorationEffect.getBoolean(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventRevitalize) {
                clazz = roborace.client.EventRevitalize.class;
                Field playerID = clazz.getDeclaredField("playerID");
                Field startID = clazz.getDeclaredField("startID");
                playerID.setAccessible(true);
                startID.setAccessible(true);
                result = new roborace.server.EventRevitalize(playerID.getInt(event), startID.getInt(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventRunDecorations) {
                clazz = roborace.client.EventRunDecorations.class;
                Field phase = clazz.getDeclaredField("phase");
                phase.setAccessible(true);
                result = new roborace.server.EventRunDecorations(phase.getInt(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventStep) {
                clazz = roborace.client.EventStep.class;
                Field playerID = clazz.getDeclaredField("playerID");
                Field direction = clazz.getDeclaredField("direction");
                playerID.setAccessible(true);
                direction.setAccessible(true);
                result = new roborace.server.EventStep(playerID.getInt(event), (Direction) direction.get(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventTurn90) {
                clazz = roborace.client.EventTurn90.class;
                Field playerID = clazz.getDeclaredField("playerID");
                Field clockwise = clazz.getDeclaredField("clockwise");
                playerID.setAccessible(true);
                clockwise.setAccessible(true);
                result = new roborace.server.EventTurn90(playerID.getInt(event), clockwise.getBoolean(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventTurn180) {
                clazz = roborace.client.EventTurn180.class;
                Field playerID = clazz.getDeclaredField("playerID");
                playerID.setAccessible(true);
                result = new roborace.server.EventTurn180(playerID.getInt(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventVictory) {
                clazz = roborace.client.EventVictory.class;
                Field playerID = clazz.getDeclaredField("playerID");
                playerID.setAccessible(true);
                result = new roborace.server.EventVictory(playerID.getInt(event)).toXMLString();
            }
            if (event instanceof roborace.client.EventWait) {
                result = new roborace.server.EventWait().toXMLString();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

    public static boolean testEvent(roborace.server.Event event) {
        XMLReader<roborace.client.Event> reader = new XMLReader();
        String eventKind = event.getClass().getName();
        String[] s = eventKind.split("\\.");
        eventKind = s[s.length - 1];
        reader.setXMLSchema(eventKind + ".xsd");
        reader.setXMLNodeConverter(new EventReader());
        String stringBefore = event.toXMLString();
        roborace.client.Event eventAfter = reader.readXML(new StringReader(stringBefore));
        String stringAfter = ToXMLString(eventAfter);
        System.out.println(stringBefore);
        System.out.println(stringAfter);
        return stringBefore.equals(stringAfter);
    }

    public static void main(String[] args) {
        ImageManager.getInstance().setImagePath("./Images/");
        ImageAndAnimationFactory.getInstance();
        XMLReader.setXSDPath("./XSD/");

        /*
        for testing (below)
        */
         
        //roborace.server.Event event = ;
        //System.out.println(testEvent(event));
    }
}
