package roborace.server;

public class EventEffectEnd implements Event {

    @Override
    public String toXMLString() {
        return "<EventEffectEnd/>";
    }    
}