package roborace.server;

import COSC3P91.xml.XMLObject;

public interface Event extends XMLObject {
}
