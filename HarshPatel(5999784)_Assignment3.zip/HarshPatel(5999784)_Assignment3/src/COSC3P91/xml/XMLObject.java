package COSC3P91.xml;

public interface XMLObject {
	
	public String toXMLString();	
}