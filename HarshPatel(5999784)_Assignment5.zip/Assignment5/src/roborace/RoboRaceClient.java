package roborace;

import COSC3P91.graphics.ImageManager;
import COSC3P91.xml.XMLReader;
import java.io.IOException;
import java.net.Socket;
import javax.swing.JDialog;
import javax.swing.JFrame;
import roborace.client.ImageAndAnimationFactory;
import roborace.client.Player;
import roborace.client.RoboRaceSoundManager;
import roborace.common.NetworkPort;
import roborace.common.GameDialogs;
import roborace.common.Port;

public class RoboRaceClient {

    private static final int PORT = 10997;
    private static final String HOST = "localhost";

    public static void main(String[] args) {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
        ImageManager.getInstance().setImagePath("./Images/");
        ImageAndAnimationFactory.getInstance();
        RoboRaceSoundManager.getInstance(); // uncomment this later so that the RoboRaceSoundManager gets instantiated early.
        XMLReader.setXMLPath("./");
        XMLReader.setXSDPath("./XSD/");

        String name = null;
        Socket socket;
        NetworkPort network = null;
        int playerID = 0;
        while (name == null) {
            try {
                name = GameDialogs.showInputDialog("Name", "Please enter your name:", null);
            } catch (Exception e) {
            }
        }

        try {

            while (true) {
                try {
                    socket = new Socket(HOST, PORT);
                    break;
                } catch (Exception e) {
                }
            }
            network = new NetworkPort(socket);
            network.send(name);
            network.receive();
            playerID = Integer.parseInt(network.receive());
            new Player(playerID, network);

        } catch (Exception e) {
        }
        (new Player(playerID, network)).run();

    }
}
