package roborace.server;

public class EventWait implements Event {
    
    @Override
    public String toXMLString() {
        return "<EventWait/>";
    }
}