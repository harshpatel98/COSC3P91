package roborace.common;

import java.net.Socket;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public class NetworkPort implements Port {

    private Socket socket;
    private BufferedReader read;
    private PrintWriter write;

    public NetworkPort(Socket socket) {
        this.socket = socket;
        try {
            this.read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.write = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
        } catch (IOException e) {
        }
    }

    @Override
    public synchronized void send(String message) {
        write.println(message);
        write.println("\0");
        write.flush();
    }

    @Override
    public synchronized String receive() {
        String result = "";
        while (true) {
            try {
                String in = read.readLine();
                if (in.contains("\0")) {
                    break;
                }
                result += in;
            } catch (IOException e) {

            }
        }
        return result;
    }

    @Override
    public void close() throws IOException {
        write.close();
        read.close();
        socket.close();
    }
}
