package roborace;

import COSC3P91.graphics.ImageManager;
import COSC3P91.xml.XMLReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JDialog;
import javax.swing.JFrame;
import roborace.common.NetworkPort;
import roborace.common.GameDialogs;
import roborace.common.Port;
import roborace.server.GameMaster;

public class RoboRaceServer {

    private static final int PORT = 10997;

    public static void main(String[] args) {
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
        ImageManager.getInstance().setImagePath("./Images/");
        XMLReader.setXMLPath("./");
        XMLReader.setXSDPath("./XSD/");

        int nHuman = 0;
        while (nHuman == 0 || nHuman > 4) {
            try {
                nHuman = Integer.parseInt(GameDialogs.showInputDialog("Number of players", "Please, input the number of players (1-4):", null));
            } catch (NumberFormatException e) {
            }
        }
        int port = 10997;
        ServerSocket server;
        Socket sock;
        String[] names = new String[nHuman];
        NetworkPort[] ports = new NetworkPort[nHuman];
        try {
            server = new ServerSocket(port);
            for (int i = 0; i < nHuman; i++) {
                sock = server.accept();
                ports[i] = new NetworkPort(sock);
                names[i] = ports[i].receive();
            }
        } catch (IOException e) {

        }
        (new GameMaster(names, ports)).run();

    }

}
