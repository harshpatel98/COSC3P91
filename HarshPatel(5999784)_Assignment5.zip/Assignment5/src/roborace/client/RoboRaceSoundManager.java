package roborace.client;

import COSC3P91.sound.Sound;
import COSC3P91.sound.SoundManager;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

public class RoboRaceSoundManager extends SoundManager {
private static final RoboRaceSoundManager instance = new RoboRaceSoundManager();
    public Sound bump, explosion, fanfare, drivingShort, drivingLong, pusher, crusher;
    
    private RoboRaceSoundManager() {
        super(new AudioFormat(8000, 8, 1, false, false), 4);
        super.setSoundPath("./Sounds&Midi/");

        bump = getSound("bump.wav");
        explosion = getSound("explosion.wav");
        fanfare = getSound("fanfare.wav");
        drivingShort = getSound("drivingShort.wav");
        drivingLong = getSound("drivingLong.wav");
        pusher = getSound("pusher.wav");
        crusher = getSound("crusher.wav");

    }
    public static RoboRaceSoundManager getInstance(){
        return instance;
    }

    public void playBump(){
      try {
            File file = new File("./Sounds&Midi/bump.wav");
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            SoundManager s = new SoundManager(format);
            s.play(s.getSound(stream));
        }
        catch (Exception e){

        }
        
    }
    public void playExplosion(){
        try {
            File file = new File("./Sounds&Midi/explosion.wav");
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            SoundManager s = new SoundManager(format);
            s.play(s.getSound(stream));
        }
        catch (Exception e){

        }
    }
    public void playFanfare(){
        try {
            File file = new File("./Sounds&Midi/fanfare.wav");
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            SoundManager s = new SoundManager(format);
            s.play(s.getSound(stream));
        }
        catch (Exception e){

        }
    }
    public void playDrivingShort(){
        try {
            File file = new File("./Sounds&Midi/drivingShort.wav");
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            SoundManager s = new SoundManager(format);
            s.play(s.getSound(stream));
        }
        catch (Exception e){

        }
    }
    public void playDrivingLong(){
        try {
            File file = new File("./Sounds&Midi/drivingLong.wav");
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            SoundManager s = new SoundManager(format);
            s.play(s.getSound(stream));
        }
        catch (Exception e){

        }
    }
    public void playPusher(){
        try {
            File file = new File("./Sounds&Midi/Pusher.wav");
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            SoundManager s = new SoundManager(format);
            s.play(s.getSound(stream));
        }
        catch (Exception e){

        }
    }
    public void playCrusher(){
        try {
            File file = new File("./Sounds&Midi/crusher.wav");
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            SoundManager s = new SoundManager(format);
            s.play(s.getSound(stream));
        }
        catch (Exception e){

        }
    }
}
