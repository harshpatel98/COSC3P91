package roborace.server;

import roborace.client.Player;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.IOException;

public class GameMaster {

    private final Robot[] robots;
    private final Player[] players;
    private final Board board;
    private final CardFactory cardFactory;

    public GameMaster(String[] names, Player[] players) {
        //store variables
        this.players = players;
        robots = new Robot[names.length];
        //load factory
        Factory factory = Factory.load("factory.xml");

        for(int i=0; i<names.length;i++){
            robots[i] = new Robot(names[i],factory.getStartConfigByID(i),true);
        }
           board = new Board(factory,robots);
        for (Player p : players) {
            p.receiveBoard(board);
        }
        cardFactory = new CardFactory();
    }
    
    public void run() {
        final int numPlayers = robots.length;
        //player card list
        CardList[] pCardList  = new CardList[numPlayers];
        for(int i=0; i<numPlayers; i++) {
            pCardList[i] = new CardList();
        }
        //past list
        CardList phaseList = new CardList();
        //events list
        EventList events = new EventList();
        List<Integer> effectExecutionOrder = new ArrayList<Integer>(numPlayers);
        for (int i=0; i<numPlayers; i++) {
            effectExecutionOrder.add(i);
        }
        
        //phases of events
        int phase;
        
        //keep looping until theres a victory
        while(!events.containsVictory()) {
            
            //reset all cards and fill the, with new ones
            for (int i = 0; i < numPlayers; i++) {
               //clear cards
                pCardList[i].clear();
                for(int j=0; j<7; j++){
                    //add new cards
                    pCardList[i].add(cardFactory.createCard(i));

                }
                //players select cards
                pCardList[i] = players[i].selectCards(pCardList[i]);
            }
            phase = 0;
            events.clear();
            /*there will be a max of 5 phases (cards selected) 
             *AND until theres a victory
            */
            while (phase < 5 && !events.containsVictory()){
                phase ++;
                phaseList.clear();
                
                //get the cards of each player
                for (int i=0; i<numPlayers; i++){
                    phaseList.add(pCardList[i].get(phase-1));
                }  
                //sort cards
                Collections.sort(phaseList);
                //execute cards
                for(Card card : phaseList){
                    card.execute(events, board);
                }
                //sort and shuffle cards form list
                Collections.sort(effectExecutionOrder);
                Collections.shuffle(effectExecutionOrder);
                for(int playerID : effectExecutionOrder){
                    board.effect(events, playerID, phase);
                }
                //if theres isn't a victory a EventRunDecorations is too to the event list
                if(!events.containsVictory()){
                    events.add (new EventRunDecorations(phase));
                }                
            }
            //if the board doesn't have a victory revieve all dead bots
            if(!events.containsVictory()){
                board.revitalize(events);
            }
            //give event list to each player
            for (Player p : players){
                p.receiveEvents(events);
            }
        }
   }
}
